#include "print.hpp"
#include <iostream>
#include <vector>
#include <utility>
#include <stdexcept>
#include <cstdlib>
#include <ctime>
#include <algorithm>

using lib::print;
int main(int argc, char *argv[])
{

    return 0;
}