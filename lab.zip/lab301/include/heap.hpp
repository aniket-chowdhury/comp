#include "list.hpp"

namespace lib
{

template<typename T>
class heap
{
public:
list l;
    
};
} // namespace lib